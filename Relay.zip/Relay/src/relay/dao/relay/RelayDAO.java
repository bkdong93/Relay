package relay.dao.relay;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import relay.mapper.relay.RelayMapper;
import relay.vo.message.MessageVO;
import relay.vo.relay.RelayVO;

@Repository
public class RelayDAO {

	@Autowired
	private SqlSessionFactory factory;
	
	public List<RelayVO> getRelay(int rno) {
		List<RelayVO> list = null;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			list = mapper.getRelay(rno);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<RelayVO> getRname(int mno) {
		List<RelayVO> list = null;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			list = mapper.getRname(mno);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int insertRelay(MessageVO vo) {
		int result = 0;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			result = mapper.insertRelay(vo);
			if (result > 0) {
				factory.openSession().commit();
			} else {
				factory.openSession().rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int insertRdetail(MessageVO vo) {
		int result = 0;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			result = mapper.insertRdetail(vo);
			if (result > 0) {
				factory.openSession().commit();
			} else {
				factory.openSession().rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int insertRdetailForInvited(int mno2, int rno) {
		int result = 0;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			result = mapper.insertRdetailForInvited(mno2, rno);
			if (result > 0) {
				factory.openSession().commit();
			} else {
				factory.openSession().rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<RelayVO> getList(int rno) {
		List<RelayVO> list = null;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			list = mapper.getList(rno);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int updateRelayProduct(long pno, int mno, int rno) {
		int result = 0;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			result = mapper.updateRelayProduct(rno, pno, mno);
			if (result > 0) {
				factory.openSession().commit();
			} else {
				factory.openSession().rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int outRelay(int rno, int mno) {
		int result = 0;
		try {
			RelayMapper mapper = factory.openSession().getMapper(RelayMapper.class);
			result = mapper.outRelay(rno, mno);
			if (result > 0) {
				factory.openSession().commit();
			} else {
				factory.openSession().rollback();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}

package relay.dao.wishlist;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import relay.mapper.wishlist.WishlistMapper;
import relay.vo.wishlist.WishlistVO;

@Repository
public class WishlistDAO {
	
	@Autowired
	private SqlSessionFactory factory;
	
	public List<WishlistVO> getList(String mno) {
		List<WishlistVO> list = null;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			list = mapper.getWishlist(mno);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	

	public int getTotal(String mno) {
		int cnt = 0;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			cnt = mapper.getTotal(mno);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}

	public int insertWishlist(Long pid, int mno) {
		int result = 0;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			result = mapper.insertWishlist(pid, mno);
			if(result > 0) {
				return result;
			}else {
				return 0;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int deleteWishlist(String pno, String mno) {
		int result = 0;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			result = mapper.deleteWishlist(pno, mno);
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}


	public int updateGrade(String pno, String mno, int grade) {
		int result = 0;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			result = mapper.updateGrade(pno, mno, grade);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}


	public List<WishlistVO> getMostWishedList() {
		List<WishlistVO> list = null;
		try {
			WishlistMapper mapper = factory.openSession().getMapper(WishlistMapper.class);
			list = mapper.getMostWishedList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
}

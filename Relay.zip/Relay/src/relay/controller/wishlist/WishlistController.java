package relay.controller.wishlist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import relay.biz.product.ProductBIZ;
import relay.biz.wishlist.WishlistBIZ;
import relay.vo.product.ProductVO;
import relay.vo.wishlist.WishlistVO;

@RestController
public class WishlistController {
	
	@Autowired
	private WishlistBIZ wBiz;
	
	@Autowired
	private ProductBIZ pBiz;
	
	@RequestMapping("/wishlist.do")
	public ModelAndView getList(@RequestParam("mno") String mno) {
		List<WishlistVO> list = wBiz.getList(mno);
		ModelAndView mav = new ModelAndView();
		mav.addObject("wishlist", list);
		mav.setViewName("wishlist/list");
		return mav;
	}
	
	@RequestMapping("/wishlist/getMostWishedList.do")
	public List<WishlistVO> getMostWishedList() {
		List<WishlistVO> list = wBiz.getMostWishedList();
		return list;
	}
	
	@RequestMapping("/wishlist/list.do")
	public List<WishlistVO> getListDetail(@RequestParam String mno) {
		List<WishlistVO> list = wBiz.getList(mno);
		return list;
	}
	
	@RequestMapping("/wishlist/cnt.do")
	public int getTotal(@RequestParam String mno) {
		int cnt = wBiz.getTotal(mno);
		return cnt;
	}
	
	@PostMapping(value = "/wishlist/insert.do", consumes = "application/json", produces = { MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> insertWishlist(@RequestBody ProductVO vo){
		ProductVO pVO = pBiz.getProduct(vo.getPid());
		int result = 0;
		int insertCount = 1;
		if (pVO == null) {
			pBiz.insertProduct(vo);
			pVO = pBiz.getProduct(vo.getPid());
			result = wBiz.insertWishlist(pVO.getPid(), vo.getMno());
			if(result > 0) {
				insertCount = 1;
			}else {
				insertCount = 0;
			}
		}else {
			pVO = pBiz.getProduct(vo.getPid());
			result = wBiz.insertWishlist(pVO.getPid(), vo.getMno());
			if(result > 0) {
				insertCount = 1;
			}else {
				insertCount = 0;
			}
		}
		return insertCount == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping(value = "/wishlist/delete.do", produces = { MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> deleteWishlist(@RequestParam("pno") String pno, @RequestParam("mno") String mno) {
		int result = wBiz.deleteWishlist(pno, mno);
		return result == 1 
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping(value = "/wishlist/updateGrade.do", produces = { MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> updateGrade(@RequestParam("pno") String pno, @RequestParam("mno") String mno, @RequestParam("grade") int grade) {
		int result = wBiz.updateGrade(pno, mno, grade);
		return result == 1 
				? new ResponseEntity<>("success", HttpStatus.OK)
						: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

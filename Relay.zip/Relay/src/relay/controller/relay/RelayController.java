package relay.controller.relay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import relay.biz.product.ProductBIZ;
import relay.biz.relay.RelayBIZ;
import relay.vo.product.ProductVO;
import relay.vo.relay.RelayVO;

@RestController
public class RelayController {
	
	@Autowired
	private RelayBIZ ryBiz;
	
	@Autowired
	private ProductBIZ pBiz;
	
	@RequestMapping("/relay.do")
	public List<RelayVO> getRelay(@RequestParam("rno") int rno){
		List<RelayVO> list = ryBiz.getRelay(rno);
		return list;
	}
	
	@RequestMapping("/relay/getRelay.do")
	public ModelAndView getRelayList(@RequestParam("rno") int rno){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("relay/relay");
		mav.addObject("rno", rno);
		return mav;
	}
	
	@RequestMapping("/relay/list.do")
	public List<RelayVO> getList(@RequestParam("rno") int rno){
		List<RelayVO> list = ryBiz.getList(rno);
		return list;
	}
	
	@RequestMapping("/relay/getRname.do")
	public List<RelayVO> getRno(@RequestParam("mno") int mno){
		List<RelayVO> list = ryBiz.getRname(mno);
		return list;
	}
	
	@RequestMapping("/relay/updateRelayProduct.do")
	public ResponseEntity<String> updateRelayProduct(@RequestBody ProductVO vo){
		ProductVO pVO = pBiz.getProduct(vo.getPid());
		int result = 0;
		int insertCount = 1;
		if (pVO == null) {
			pBiz.insertProduct(vo);
			pVO = pBiz.getProduct(vo.getPid());
			result = ryBiz.updateRelayProduct(pVO.getPno(), vo.getMno(), vo.getRno());
			if(result > 0) {
				insertCount = 1;
			}else {
				insertCount = 0;
			}
		}else {
			pVO = pBiz.getProduct(vo.getPid());
			result = ryBiz.updateRelayProduct(pVO.getPno(), vo.getMno(), vo.getRno());
			if(result > 0) {
				insertCount = 1;
			}else {
				insertCount = 0;
			}
		}
		return insertCount == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping(value = "/relay/out.do", produces = { MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> outRelay(@RequestParam("rno") int rno, @RequestParam("mno") int mno) {
		int result = ryBiz.outRelay(rno, mno);
		return result == 1 
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}

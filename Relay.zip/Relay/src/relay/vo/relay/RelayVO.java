package relay.vo.relay;

public class RelayVO {
	
	private int rno;
	private int mno;
	private String rname;
	private int rage;
	private String rgender;
	private String rjob;
	private String rhobby;
	private String name;
	private String nick;
	private long pno;
	private long pid;
	private String pname;
	private int phprice;
	private int plprice;
	private String pmall;
	private String pmallurl;
	private String pimg;
	private long catid;
	private String tags;
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public int getRage() {
		return rage;
	}
	public void setRage(int rage) {
		this.rage = rage;
	}
	public String getRgender() {
		return rgender;
	}
	public void setRgender(String rgender) {
		this.rgender = rgender;
	}
	public String getRjob() {
		return rjob;
	}
	public void setRjob(String rjob) {
		this.rjob = rjob;
	}
	public String getRhobby() {
		return rhobby;
	}
	public void setRhobby(String rhobby) {
		this.rhobby = rhobby;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public long getPno() {
		return pno;
	}
	public void setPno(long pno) {
		this.pno = pno;
	}
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPhprice() {
		return phprice;
	}
	public void setPhprice(int phprice) {
		this.phprice = phprice;
	}
	public int getPlprice() {
		return plprice;
	}
	public void setPlprice(int plprice) {
		this.plprice = plprice;
	}
	public String getPmall() {
		return pmall;
	}
	public void setPmall(String pmall) {
		this.pmall = pmall;
	}
	public String getPmallurl() {
		return pmallurl;
	}
	public void setPmallurl(String pmallurl) {
		this.pmallurl = pmallurl;
	}
	public String getPimg() {
		return pimg;
	}
	public void setPimg(String pimg) {
		this.pimg = pimg;
	}
	public long getCatid() {
		return catid;
	}
	public void setCatid(long catid) {
		this.catid = catid;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	
}

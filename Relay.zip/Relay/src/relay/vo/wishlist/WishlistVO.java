package relay.vo.wishlist;

public class WishlistVO {
	
	private int mno;
	private String name;
	private int pno;
	private Long pid;
	private String pname;
	private int phprice;
	private int plprice;
	private String pmall;
	private String pmallurl;
	private String pimg;
	private long catid;
	private int grade;
	private String tags;
	private String lcat;
	
	public Long getPid() {
		return pid;
	}
	public void setPid(Long pid) {
		this.pid = pid;
	}
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPhprice() {
		return phprice;
	}
	public void setPhprice(int phprice) {
		this.phprice = phprice;
	}
	public int getPlprice() {
		return plprice;
	}
	public void setPlprice(int plprice) {
		this.plprice = plprice;
	}
	public String getPmall() {
		return pmall;
	}
	public void setPmall(String pmall) {
		this.pmall = pmall;
	}
	public String getPmallurl() {
		return pmallurl;
	}
	public void setPmallurl(String pmallurl) {
		this.pmallurl = pmallurl;
	}
	public String getPimg() {
		return pimg;
	}
	public void setPimg(String pimg) {
		this.pimg = pimg;
	}
	public long getCatid() {
		return catid;
	}
	public void setCatid(long catid) {
		this.catid = catid;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getLcat() {
		return lcat;
	}
	public void setLcat(String lcat) {
		this.lcat = lcat;
	}
	
}

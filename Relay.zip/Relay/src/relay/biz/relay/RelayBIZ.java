package relay.biz.relay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import relay.dao.relay.RelayDAO;
import relay.vo.message.MessageVO;
import relay.vo.relay.RelayVO;

@Service
public class RelayBIZ {
	
	@Autowired
	private RelayDAO dao;

	public List<RelayVO> getRelay(int rno) {
		return dao.getRelay(rno);
	}

	public List<RelayVO> getRname(int mno) {
		return dao.getRname(mno);
	}

	public int insertRelay(MessageVO vo) {
		return dao.insertRelay(vo);
	}

	public int insertRdetail(MessageVO vo) {
		return dao.insertRdetail(vo);
	}

	public int insertRdetailForInvited(int mno2, int rno) {
		return dao.insertRdetailForInvited(mno2, rno);
	}

	public List<RelayVO> getList(int rno) {
		return dao.getList(rno);
	}

	public int updateRelayProduct(long pno, int mno, int rno) {
		return dao.updateRelayProduct(pno, mno, rno);
	}

	public int outRelay(int rno, int mno) {
		return dao.outRelay(rno, mno);
	}
	
}

package relay.biz.wishlist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import relay.dao.wishlist.WishlistDAO;
import relay.vo.wishlist.WishlistVO;

@Service
public class WishlistBIZ {
	
	@Autowired
	WishlistDAO dao;

	public List<WishlistVO> getList(String mno) {
		return dao.getList(mno);
	}

	public int getTotal(String mno) {
		return dao.getTotal(mno);
	}
	
	public int insertWishlist(Long pid, int mno) {
		return dao.insertWishlist(pid, mno);
	}

	public int deleteWishlist(String pno, String mno) {
		return dao.deleteWishlist(pno, mno);
	}

	public int updateGrade(String pno, String mno, int grade) {
		return dao.updateGrade(pno, mno, grade);
	}

	public List<WishlistVO> getMostWishedList() {
		return dao.getMostWishedList();
	}


}
